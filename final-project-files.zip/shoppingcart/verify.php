<?php

require("header.php");

//check whether the verification code received is correct
$verifystring = urldecode($_GET['verify']);
$verifyemail = urldecode($_GET['email']);

//check whether the verification code 
$sql = "SELECT id FROM users WHERE verifystring = '" . $verifystring . "' AND email = '" . $verifyemail . "';";
$result = mysql_query($sql);
$numrows = mysql_num_rows($result);

//check whether the result returned is equal to 1
if($numrows == 1) {
	$row = mysql_fetch_assoc($result);
	
	//if the result returned is equal to 1, activate the user
	$sql = "UPDATE users SET active = 1 WHERE id = " . $row['id'];
	$result = mysql_query($sql);

//provide user with success message
	echo "Your account has now been verified. You can now <a href='login.php'>LOG IN</a>";
}

//if the verification code failed to satisfy the parameters above, provide user with failure message
else {
	echo "This account could not be verified.";
}

echo $verifystring;

require("footer.php");

?>

