<?php
	session_start();
	require("db.php");

	//sql query to check the status of the current order
	$statussql = "SELECT status FROM orders WHERE id = " . $_SESSION['SESS_ORDERNUM'];
	$statusres = mysql_query($statussql);
	$statusrow = mysql_fetch_assoc($statusres);
	$status = $statusrow['status'];

	//if the user has already input his/her address, redirect the page to the payment page
	if($status == 1) {	
		header("Location: " . $config_basedir . "checkout-pay.php");
	}

	//if status is greater than or equal to 2, the order has already been completed, therefore redirect page to the home page of the website
	if($status >= 2) {	
		header("Location: " . $config_basedir);
	}

	//check whether the 'Add Address' button has been pressed
	if($_POST['submit'])
	{
		
		//check if the user is logged in
		if($_SESSION['SESS_LOGGEDIN'])
		{
			
			//check if user checked the second radio button
			if($_POST['addselecBox'] == 2)
			{
				
				//check if the required form fields are empty
				if(empty($_POST['forenameBox']) ||
					empty($_POST['surnameBox']) ||
					empty($_POST['add1Box']) ||
					empty($_POST['add2Box']) ||
					empty($_POST['add3Box']) ||
					empty($_POST['postcodeBox']) ||
					empty($_POST['phoneBox']) ||
					empty($_POST['emailBox']))
				{
					
					//if the form fields are empty, display an error message
					header("Location: " . $basedir . "checkout-address.php?error=1");
					exit;
				}
			
				//if the form fields are not empty, add the address into the 'delivery_addresses' table 
				$addsql = "INSERT INTO delivery_addresses(forename, surname, add1, add2, add3, postcode, phone, email)
							VALUES('"
							. strip_tags(addslashes($_POST['forenameBox'])) . "', '"
							. strip_tags(addslashes($_POST['surnameBox'])) . "', '"
							. strip_tags(addslashes($_POST['add1Box'])) . "', '"
							. strip_tags(addslashes($_POST['add2Box'])) . "', '"
							. strip_tags(addslashes($_POST['add3Box'])) . "', '"
							. strip_tags(addslashes($_POST['postcodeBox'])) . "', '"
							. strip_tags(addslashes($_POST['phoneBox'])) . "', '"
							. strip_tags(addslashes($_POST['emailBox'])) . "')";
				
				mysql_query($addsql);

				//update the shopping cart status to 1
				$setaddsql = "UPDATE orders SET delivery_add_id = " . mysql_insert_id() . ", status = 1 WHERE id = " . $_SESSION['SESS_ORDERNUM'];
				mysql_query($setaddsql);

				//redirect page to the 'check-out.php' page
				header("Location: " . $config_basedir . "checkout-pay.php");
			}
			else
			{
				
				//if the user is logged in but selects the address already in the customers table, update orders and set status to 1				
				$custsql = "UPDATE orders SET delivery_add_id = 0, status = 1 WHERE id = " . $_SESSION['SESS_ORDERNUM'];
				mysql_query($custsql);
				header("Location: " . $config_basedir . "checkout-pay.php");
			}
		}
		
		//if the user is not logged in, validate the form to check whether the the form fields are empty
		else
		{
			if(empty($_POST['forenameBox']) ||
				empty($_POST['surnameBox']) ||
				empty($_POST['add1Box']) ||
				empty($_POST['add2Box']) ||
				empty($_POST['add3Box']) ||
				empty($_POST['postcodeBox']) ||
				empty($_POST['phoneBox']) ||
				empty($_POST['emailBox']))
			{
				
				//if the form fields are empty, display error message
				header("Location: " . "checkout-address.php?error=1");
				exit;
			}

			//if the form fields are not empty, add the address to the 'delivery_addresses' table
			$addsql = "INSERT INTO delivery_addresses(forename, surname, add1, add2, add3, postcode, phone, email)
					VALUES('"
					. $_POST['forenameBox'] . "', '"
					. $_POST['surnameBox'] . "', '"
					. $_POST['add1Box'] . "', '"
					. $_POST['add2Box'] . "', '"
					. $_POST['add3Box'] . "', '"
					. $_POST['postcodeBox'] . "', '"
					. $_POST['phoneBox'] . "', '"
					. $_POST['emailBox'] . "')";
		
				mysql_query($addsql);

			//update status to 1
			$setaddsql = "UPDATE orders SET delivery_add_id = " . mysql_insert_id() . ", status = 1 WHERE session = '" . session_id() . "'";
			mysql_query($setaddsql);

			//redirect the page to 'checkout-pay.php' page
			header("Location: " . $config_basedir . "checkout-pay.php");		
		}
	}
	else
	{
	
	require("header.php");
	echo "<h1>Add a delivery address</h1>";
	echo "<a href='catalog.php'><--- Continue shopping</a>";
	echo "<p>";
	echo "<a href='showcart.php'><--- Review your shoppingcart</a>";
	echo "<p>";
	
	//if the 'Add Address' button has been pressed and there is no entry in the fields required, display an error message
	if(isset($_GET['error']) == TRUE) {
		echo "<strong>Please fill in the missing information...</strong>";
	}
	
	echo "<form action='" . $SCRIPT_NAME . "' method='POST' onsubmit='return formValidator()' >";
	
	//check if user is logged in
	if($_SESSION['SESS_LOGGEDIN'])
	{
		//if user is logged in, display two radio buttons to provide two different options
	?>
	<input type="radio" name="addselecBox" value="1" checked>Use the address from my account</input><br>
	<input type="radio" name="addselecBox" value="2">Use the address below:</input>
	<?php
	}
	
	?>
    
    <script type='text/javascript'>
//validate user input
function formValidator(){
	// Make quick references to our fields
	var forenameBox = document.getElementById('forenameBox');
	var surnameBox = document.getElementById('surnameBox');
	var add1Box = document.getElementById('add1Box');
	var add2Box = document.getElementById('add2Box');
	var add3Box = document.getElementById('add3Box');
	var postcodeBox = document.getElementById('postcodeBox');
	var phoneBox = document.getElementById('phoneBox');
	var emailBox = document.getElementById('emailBox');
	// Check each input in the order that it appears in the form!
	if(isAlphabet(forenameBox, "Please enter only letters for your forename")){
		if(isAlphabet(surnameBox, "Please enter only letters for your surname")){
		if(isAlphanumeric(add1Box, "Numbers and Letters Only for Address")){
			if(isAlphabet(add2Box, "Please enter only letters for your Town/City")){
			if(isAlphabet(add3Box, "Please enter only letters for your State/Province/County")){
			if(isNumeric(postcodeBox, "Please enter a valid Postcode/Zip code")){
				if(isNumeric(phoneBox, "Please enter a valid telephone number")){
					
						if(emailValidator(emailBox, "Please enter a valid email address")){
							return true;
						}
					}
				}
			}
		}
		}
		}
	}
	
	return false;
	
}

//ensure all fields are not empty
function notEmpty(elem, helperMsg){
	if(elem.value.length == 0){
		alert(helperMsg);
		elem.focus(); // set the focus to this input
		return false;
	}
	return true;
}

//function to validate the input in numeric fields
function isNumeric(elem, helperMsg){
	var numericExpression = /^[0-9]+$/;
	if(elem.value.match(numericExpression)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}

//function to validate the input alphabetical fields 
function isAlphabet(elem, helperMsg){
	var alphaExp = /^[a-zA-Z]+$/;
	if(elem.value.match(alphaExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}

//function to validate alphanumeric fields
function isAlphanumeric(elem, helperMsg){
	var alphaExp = /^[0-9a-zA-Z]+$/;
	if(elem.value.match(alphaExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}

//function to validate email fields
function emailValidator(elem, helperMsg){
	var emailExp = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
	if(elem.value.match(emailExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}

</script>

    <table>
    <tr>
			<td>Forename</td>
			<td><input type="text" name="forenameBox" id="forenameBox"></td>
		</tr>
		<tr>
			<td>Surname</td>
			<td><input type="text" name="surnameBox" id="surnameBox"></td>
		</tr>
		<tr>
			<td>House Number/Street/P.O Box</td>
			<td><input type="text" name="add1Box" id="add1Box"></td>
		</tr>
		<tr>
			<td>Town/City</td>
			<td><input type="text" name="add2Box" id="add2Box"></td>
		</tr>
		<tr>
			<td>State/Province/County</td>
			<td><input type="text" name="add3Box" id="add3Box"></td>
		</tr>
		<tr>
			<td>Postcode/Zip Code</td>
			<td><input type="text" name="postcodeBox" id="postcodeBox"></td>
		</tr>
		<tr>
			<td>Phone</td>
			<td><input type="text" name="phoneBox" id="phoneBox"></td>
		</tr>
		<tr>
			<td>Email</td>
			<td><input type="text" name="emailBox" id="emailBox"></td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" name="submit" value="Add Address"></td>
		</tr>
		</table>
	</form>
	
<?php
	}
	require("footer.php");
?>
	
