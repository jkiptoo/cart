<?php

//start a new session
	session_start();

	//check if a previous session exists, if session exists, delete and regenerate a new session
	if(isset($_SESSION['SESS_CHANGEID']) == TRUE)
	{
		session_unset();
		session_regenerate_id();
	}

	require("config.php");
	
	//database connection details
	$db = mysql_connect($dbhost, $dbuser, $dbpassword);
	mysql_select_db($dbdatabase, $db);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><head>
<files>
<title><?php echo $config_sitename; ?></title>
	<link href="style.css" rel="stylesheet">
    <link rel="shortcut icon" href="images/favicon.ico" />
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
    <link rel="icon" type="image/x-icon"  href="images/favicon.ico">
    <link rel="icon" type="image/png" href="images/favicon.png">  
    
</head>
<body>
	<div id="header">
	<h1><?php echo $config_sitename; ?></h1>
	</div>
	<div id="menu">
		<a href="<?php echo $config_basedir; ?>">HOME</a> -
        <a href="<?php echo $config_basedir; ?>register.php">REGISTER</a> -
        <a href="<?php echo $config_basedir; ?>login.php">LOG IN</a> -
        <a href="<?php echo $config_basedir; ?>catalog.php">OUR PRODUCTS</a> -
		<a href="<?php echo $config_basedir; ?>showcart.php">VIEW YOUR CART/CHECKOUT</a>
	</div>
	<div id="container">
		<div id="bar">
			<?php
				
				//include 'bar.php' which will display the list of product categories
				require("bar.php");
				echo "<hr>";
				
				//check if user is logged in
				if(isset($_SESSION['SESS_LOGGEDIN']) == TRUE)
				{
					//if the user is logged in, display his/her username and a 'LOGOUT' link
					echo "You are logged in as <strong>" . $_SESSION['SESS_USERNAME'] . "</strong> [<a href='" . $config_basedir . "logout.php'>SIGN OUT</a>]";
				}
								
				//if user is not logged in, display a login link
				else
				{
					echo "<a href='" . $config_basedir . "login.php'>SIGN IN</a>";
				}
				
				//display link for the administrator to administer website 
				echo "<br><br><a href='adminhome.php'>ADMINISTRATOR</a></br></br>"
				
			?>
			
		</div>

		<div id="main">
