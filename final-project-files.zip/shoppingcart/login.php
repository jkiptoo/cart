<?php

//start new session
	session_start();
	require("db.php");

//check if user is already logged in; if the user is logged in, redirect to the home page
	if(isset($_SESSION['SESS_LOGGEDIN']) == TRUE) {
		header("Location: " . $config_basedir);
	}
	
	//check if user has pressed the sign in button
	if($_POST['submit'])
	{
      
            //check if user has submitted an empty form
		if(empty($_POST['userBox']) ||
		empty($_POST['passBox']))
		{
			header("Location: " .$config_basedir. "login.php?error=2");
			exit;
		}
	{
		//check whether details input to the user match those in the database records
		$loginsql = "SELECT * FROM users WHERE username = '" . $_POST['userBox'] . "' AND password = '" . $_POST['passBox'] . "'";
		$loginres = mysql_query($loginsql);
		$numrows = mysql_num_rows($loginres);
		
		//if details input by user match those in the database records
		if($numrows == 1)
		{
			$loginrow = mysql_fetch_assoc($loginres);
			
			//create session variables when user login is successful
			session_register("SESS_LOGGEDIN");
			session_register("SESS_USERNAME");
			session_register("SESS_USERID");
			
			//define session variables to indicate that the user is logged in, to hold the username and id of users
			$_SESSION['SESS_LOGGEDIN'] = 1;
			$_SESSION['SESS_USERNAME'] = $loginrow['username'];
			$_SESSION['SESS_USERID'] = $loginrow['id'];
			
			//retrieve orders from the database records whose 'customer_id' matches the id of the user who is currently logged in
			$ordersql = "SELECT id FROM orders WHERE customer_id = " . $_SESSION['SESS_USERID'] . " AND status < 2";
			$orderres = mysql_query($ordersql);
			$orderrow = mysql_fetch_assoc($orderres);
			
			//if order exists, register the 'SESS_ORDERNUM' variable
			session_register("SESS_ORDERNUM");
			$_SESSION['SESS_ORDERNUM'] = $orderrow['id'];
			
			header("Location: " . $config_basedir. "showcart.php");
		}
		
		//redirect user to an error page
		else
		{
			header("Location: " . $config_basedir . "login.php?error=1");
		}
	}
	}
	else
	{
		require("header.php");
?>
	<h1>Customer Login</h1>
	Please enter your username and password to log into this website. If you do not have an account with us, you can get one for free by clicking <a href="register.php">HERE</a>.
	<p>
	
	<?php
	
	//if wrong username and/or password were submitted by user, display an error message
		if($_GET['error'] == 1) {
			echo "<strong>Incorrect login details. Please try again.</strong>";
		}
      
       //if user submitted an empty form, display an error message
		if($_GET['error'] == 2) {
			echo "<strong>Please fill in the required fields.</strong>";
		}
	?>
	
	<form action="<?php echo $SCRIPT_NAME; ?>" method="POST">
	<table>
		<tr>
			<td>Username</td>
			<td><input type="textbox" name="userBox">
		</tr>
		<tr>
			<td>Password</td>
			<td><input type="password" name="passBox">
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" name="submit" value="SIGN IN">
		</tr>		
	</table>
	</form>
	
<?php
	}
	
	require("footer.php");
?>