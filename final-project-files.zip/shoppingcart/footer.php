
<?php
	echo "<p><i>This is " . $config_sitename . "</i></p>"; 

//check if the administrator is logged in
	if($_SESSION['SESS_ADMINLOGGEDIN'] == 1)
	{
		//if the administrator is logged in, redirect to the administrative pages and display a logout link
		echo "[<a href='" . $config_basedir . "adminhome.php'>ADMINISTRATOR</a>] [<a href='" . $config_basedir . "adminlogout.php'>ADMINISTRATOR LOGOUT</a>]";
	}
?>

</div>
	</div>
</body>
</html>
