<?php
	session_start();

	require("config.php");
	require("db.php");
	require("functions.php");
	
	//check if the adminstrator is not logged in 	
	if(isset($_SESSION['SESS_ADMINLOGGEDIN']) == FALSE) {
		
		//if the administrator is not logged in, redirect to the website's home page
		header("Location: " . $config_basedir);
	}

	//check if the ''func' GET function exists
	if(isset($_GET['func']) == TRUE) {

		//check if the 'func' function is equal to the 'conf' function, 
		if($_GET['func'] != "conf") {
			header("Location: " . $config_basedir);
		}
	
	
		//validate the id GET variable
 		$validid = pf_validate_number($_GET['id'], "redirect", $config_basedir);
	
		//update the orders table and set status to 10
		$funcsql = "UPDATE orders SET status = 10 WHERE id = " . $_GET['id'];
		mysql_query($funcsql);

		//redirect page to the 'adminorders.php' which shows the order summary
		header("Location: " . $config_basedir . "adminorders.php");
	}
	
	//if no 'func' GET variable exists, display completed orders
	else {
		require("header.php");
		echo "<h1>Outstanding orders</h1>";
		echo "<a href='adminhome.php'><--- Return to the administrative panel</a>";
		$orderssql = "SELECT * FROM orders WHERE status = 2";
		$ordersres = mysql_query($orderssql);
		$numrows = mysql_num_rows($ordersres);
		
		//if there are no orders, display message
		if($numrows == 0)
		{
			echo "<p>";
			echo "<strong>There are no orders currently.</strong>";
		}
		
		//if there are orders present, show a summarised detail of each of the orders
		else
		{				
			echo "<table cellspacing=10>";
			
			while($row = mysql_fetch_assoc($ordersres))
			{
				echo "<tr>";
				
				    //provide a link for the administrator to view more detailed information concerning the selected order
					echo "<td>[<a href='adminorderdetails.php?id=" . $row['id'] . "'>View</a>]</td>";
					echo "<td>" . date("D jS F Y g.iA", strtotime($row['date'])) . "</td>";
					echo "<td>";
					
					//if the registered field is set to 1, show message confirming the customer is registered
					if($row['registered'] == 1)
					{
						echo "Registered Customer";
					}
					else
					
					//if the registered field is set to anything else other than 1, display message stating that the user is not registered
					{
						echo "Non-Registered Customer";
					}
					
					echo "</td>";
		
					echo "<td>&pound;" . sprintf('%.2f', $row['total']) . "</td>";
	
					echo "<td>";
					
					//if the payment field is set to 1, show message stating that the payment mode is PayPal
					if($row['payment_type'] == 1)
					{
						echo "PayPal";
					}
					
					//if the payment field is set to anything other than 1, display a message stating that the payment mode is Cheque
					else
					{
						echo "Cheque";
					}
				
					echo "</td>";
			
					//display link for the administrator to confirm whether the order has been paid for
					echo "<td><a href='adminorders.php?func=conf&id=" . $row['id'] . "'>Confirm Payment</a></td>";
				echo "</tr>";	
			}

			echo "</table>";
		}
	}

	require("footer.php");
?>