<?php

	require("header.php");

	showcart();

	require("footer.php");
?>
	
