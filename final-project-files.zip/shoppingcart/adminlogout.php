<?php

	session_start();

	require("config.php");

	//reset the 'SESS_ADMINLOGGEDIN' session 
	session_unregister("SESS_ADMINLOGGEDIN");
	
	//redirect page to the website's home page
	header("Location: " . $config_basedir);
?>
	
