<?php

//function to handle page redirects
function pf_validate_number($value, $function, $redirect) {
	if(isset($value) == TRUE) {
		if(is_numeric($value) == FALSE) {
			$error = 1;
		}
	
		if($error == 1) {
			header("Location: " . $redirect);
		}
		else {
			$final = $value;
		}
	}
	else {
		if($function == 'redirect') {
			header("Location: " . $redirect);
		}
		
		if($function == "value") {
			$final = 0;
		}
	}
	
	return $final;
}

//function that extends the functionality of the 'showcart.php' page
function showcart()
{

	//determine if an order number exists
	if($_SESSION['SESS_ORDERNUM'])
	{
		
		//check if user is logged in
		if($_SESSION['SESS_LOGGEDIN'])
		{
			
			//retrieve order from the orders tables where the customer id matches the one of the current user and whose status is equal to zero or one 
			$custsql = "SELECT id, status from orders WHERE customer_id = " . $_SESSION['SESS_USERID'] . " AND status < 2;"; 
			$custres = mysql_query($custsql);
			$custrow = mysql_fetch_assoc($custres);

			$itemssql = "SELECT products.*, orderitems.*, orderitems.id AS itemid FROM products, orderitems WHERE orderitems.product_id = products.id AND order_id = " . $custrow['id'];
			$itemsres = mysql_query($itemssql);
			$itemnumrows = mysql_num_rows($itemsres);
		}
		
		//if user is not logged in, select an order number that matches the session id of the current session
		else
		{ 
			$custsql = "SELECT id, status from orders WHERE session = '" . session_id() . "' AND status < 2;"; 
			$custres = mysql_query($custsql);
			$custrow = mysql_fetch_assoc($custres);

			$itemssql = "SELECT products.*, orderitems.*, orderitems.id AS itemid FROM products, orderitems WHERE orderitems.product_id = products.id AND order_id = " . $custrow['id'];
			$itemsres = mysql_query($itemssql);
			$itemnumrows = mysql_num_rows($itemsres);
		}	
	}
	
	//if there are no orders available, set the 'itemnumrows' variable to zero
	else
	{
		$itemnumrows = 0;
	}		

	//if the result is equal to zero, display message indicating there are no items in the shopping cart
	if($itemnumrows == 0)
	{
		echo "<p>";
		echo "You have not added anything to your shopping cart yet.";
		
	}
	
	//if the results returned is equal or greater than one, display the items in the shopping cart
	else
	{			
		echo "<table cellpadding='10'>";
		echo "<tr>";
			echo "<td></td>";
			echo "<td><strong>Item</strong></td>";
			echo "<td><strong>Quantity</strong></td>";
			echo "<td><strong>Unit Price</strong></td>";
			echo "<td><strong>Total Price</strong></td>";
			echo "<td></td>";
		echo "</tr>";
			
		while($itemsrow = mysql_fetch_assoc($itemsres))
		{	
				
				//display total quantity of the products ordered
				$quantitytotal = $itemsrow['price'] * $itemsrow['quantity'];
		echo "<tr>";

				//if product has no image, display a default product image
				if(empty($itemsrow['image'])) {
					echo "<td><img src='./images/No Image.jpg' width='50' alt='" . $itemsrow['name'] . "'></td>";
				}
				
				//if product has an image, display that image
				else {
					echo "<td><img src='./images/" . $itemsrow['image'] . "' width='50' alt='" . $itemsrow['name'] . "'></td>";
				}
				
				echo "<td><img src='./images/" . $itemsrow['image'] . ".jpg' alt='" . $itemsrow['name'] . "' width='50'></td>";
				echo "<td>" . $itemsrow['name'] . "</td>";
				echo "<td>" . $itemsrow['quantity'] . "</td>";
				
				//show the total price of the order
				echo "<td><strong>&pound;" . sprintf('%.2f', $itemsrow['price']) . "</strong></td>";
				echo "<td><strong>&pound;" . sprintf('%.2f', $quantitytotal) . "</strong></td>";
				
				//include a link for a user to delete one or more of products in the shopping cart
				echo "<td>[<a href='" . $config_basedir . "delete.php?id=" . $itemsrow['itemid'] . "'>REMOVE PRODUCT FROM CART</a>]</td>";
				echo "</tr>";
			
			//update the product quantity and total price 
			$total = $total + $quantitytotal;
			}						

		echo "<tr>";
			echo "<td></td>";
			echo "<td></td>";
			echo "<td></td>";
			echo "<td>TOTAL</td>";
			echo "<td><strong>&pound;" . sprintf('%.2f', $total) . "</strong></td>";
			echo "<td></td>";
	echo "</tr>";

	echo "</table>";

	}
}

?>