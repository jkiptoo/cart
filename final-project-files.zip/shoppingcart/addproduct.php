<?php

session_start();

require("db.php");

//check if administrator is logged in; if not redirect page to the administrator login page
if(isset($_SESSION['SESS_ADMINLOGGEDIN']) == FALSE) {
	header("Location: " . $config_basedir . "adminlogin.php");
}

//check if user has submitted an empty form; if ser has submitted an empty form, display error message
if($_POST['submit']) {
	if(empty($_POST['category']) ||
	empty($_POST['name']) ||
	empty($_POST['description']) ||
	empty($_POST['price']))
	{
			header("Location: " .$config_basedir. "addproduct.php?error=1");
			exit;
		}
		//if user has submitted the reqired fields, insert the data into the products table 
		else
		{
	$prodsql = "INSERT INTO products(cat_id, name, description, image, price) VALUES('"
				. $_POST['category']
				. "', '" . $_POST['name']
				. "', '" . $_POST['description']
				. "', '" . $_POST['image']
				. "', '" . $_POST['price'] 
				. "')";
	mysql_query($prodsql);
	//after finishing adding a new product,redirect page to the adminupload page where the administrator can upload an image for the product
	header("Location: " . $config_basedir . "adminupload.php");
}
}
else {
	require("header.php");
	echo "<h1>Add a new product</h1>";
	echo "<a href='adminhome.php'><--- Return to the administrative panel</a>";
	echo "<p>";
	//error message displayed when a user submits an empty page
	if ($_GET['error'] == 1) {
		echo "<strong>Please fill in the required fields!</strong>";
	}

?>
	<p>
   <?php echo "<form action='" . $SCRIPT_NAME . "' method='POST' onsubmit='return formValidator()' >";?>
	
    <script type='text/javascript'>
//validate user input
function formValidator(){
	// Make quick references to our fields
	var name = document.getElementById('name');
	var description = document.getElementById('description');
	var price= document.getElementById('price');
	
	// Check each input in the order that it appears in the form!
	if(isAlphanumeric(name, "Please enter only letters and/or numbers for the name field")){
		if(isAlphabet(description, "Please enter only letters for the product description")){
			if(isNumeric(price, "Please use numbers only")){
				return true;
						}
					}
				}
			
			return false;
			}

//function to validate the input in numeric fields
function isNumeric(elem, helperMsg){
	var numericExpression = /^[0-9]+$/;
	if(elem.value.match(numericExpression)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}

//function to validate the input alphabetical fields 
function isAlphabet(elem, helperMsg){
	var alphaExp = /^[a-zA-Z]+$/;
	if(elem.value.match(alphaExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}

//function to validate alphanumeric fields
function isAlphanumeric(elem, helperMsg){
	var alphaExp = /^[0-9a-zA-Z]+$/;
	if(elem.value.match(alphaExp)){
		return true;
	}else{
		alert(helperMsg);
		elem.focus();
		return false;
	}
}

</script>

    
    <table cellpadding="5">
	<tr>
		<td>Category</td>
		<td>
		<?php
		//check if user is logged in as an administrator
			if($_SESSION['SESS_ADMINLOGGEDIN']) {
				$sql = "SELECT * FROM categories ORDER BY name ASC;";
				$result = mysql_query($sql);
			}
					
			echo "<select name='category'>";
			
			while($row = mysql_fetch_assoc($result)) {
				echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
			}
			
			echo "</select>";
		?>
		</td>
	</tr>
	<tr>
		<td>Product name</td>
		<td><input type="text" name="name" id="name"></td>
	</tr>
    <tr>
		<td>Description</td>
		<td><input type="text" name="description" id="description"></td>
	</tr>
    <tr>
		<td>Image (e.g. compaq.jpg)- This field can be left empty if no image is currently available</td>
		<td><input type="text" name="image" id="image"></td>
	</tr>
    <tr>
		<td>Product Price (In GBP)</td>
		<td><input type="text" name="price" id="price"></td>
	</tr>
	<tr>
		<td></td>
		<td><input type="submit" name="submit" value="Add Product"></td>
	</tr>
	</table>
	</form>

<?php
}

require("footer.php");

?>