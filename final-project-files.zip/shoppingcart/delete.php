<?php

	require("config.php");
	require("db.php");
	require("functions.php");

	//get id passed on to the page from the 'showcart.php' page
	$validid = pf_validate_number($_GET['id'], "redirect", $config_basedir . "showcart.php");
	
	//retrieve item from the orderitems  
	$itemsql = "SELECT * FROM orderitems WHERE id = " . $_GET['id'] . ";";
	$itemres = mysql_query($itemsql);
	
	//check number of rows to prevent sql injection
	$numrows = mysql_num_rows($itemres);
	
	//if no row is returned, redirect to the 'showcart.php' page
	if($numrows == 0) {
		header("Location: " . $config_basedir . "showcart.php");
	}
	
	$itemrow = mysql_fetch_assoc($itemres);

	//if rows are returned, retrieve the product's price 
	$prodsql = "SELECT price FROM products WHERE id = " . $itemrow['product_id'] . ";";
	$prodres = mysql_query($prodsql);
	$prodrow = mysql_fetch_assoc($prodres);
	
	//remove the item from the orderitems table
	$sql = "DELETE FROM orderitems WHERE id = " . $_GET['id'];
	mysql_query($sql);
	
	//update the orders table with the new total price
	$totalprice = $prodrow['price'] * $itemrow['quantity'] ;

	$updsql = "UPDATE orders SET total = total - " . $totalprice . " WHERE id = " . $_SESSION['SESS_ORDERNUM'] . ";";
	mysql_query($updres);

	//redirect to the 'showcart.php' page
	header("Location: " . $config_basedir . "showcart.php");

?>
	
