<?php

	session_start();

	require("config.php");
	
//logout user by unregistering session variables for the current session
	session_unregister("SESS_LOGGEDIN");
	session_unregister("SESS_USERNAME");
	session_unregister("SESS_USERID");
	
	header("Location: " . $config_basedir);
?>
	
