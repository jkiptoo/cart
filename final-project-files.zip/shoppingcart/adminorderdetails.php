<?php

	session_start();
	
	require("config.php");
	require("functions.php");

	//check if the administrator is not logged in, if he/she is not logged in,redirect to the website's main page
	if(isset($_SESSION['SESS_ADMINLOGGEDIN']) == FALSE) {
		header("Location: " . $basedir);
	}
	//validate the id GET variable
	$validid = pf_validate_number($_GET['id'], "redirect", $config_basedir . "adminorders.php");

	require("header.php");
	
	echo "<h1>Order Details</h1>";
	//display links for the administrator to return to the administrative panel and main orders pages
	echo "<a href='adminhome.php'><--- Return to the administrative panel</a>";
	echo "<p>";
	echo "<a href='adminorders.php'><-- Return to the main orders screen</a>";
	
	//retrieve order from the 'orders' table whose id matches the id passed on to the page using the id GET variable
	$ordsql = "SELECT * from orders WHERE id = " . $validid; 
	$ordres = mysql_query($ordsql);
	$ordrow = mysql_fetch_assoc($ordres);

	//display details of the order
	echo "<table cellpadding=10>";
	echo "<tr><td><strong>Order Number</strong></td><td>" . $ordrow['id'] . "</td>";
	echo "<tr><td><strong>Date of order</strong></td><td>" . date('D jS F Y g.iA', strtotime($ordrow['date'])) . "</td>";
	echo "<tr><td><strong>Payment Type</strong></td><td>";
	
	//if the payment field in the 'orders' table is set to 1, state that the payment mode is PayPal
	if($ordrow['payment_type'] == 1)
	{
		echo "PayPal";
	}
	
	//if the payment field is set to anything else other than 1, state that the payment mode is Cheque
	else
	{
		echo "Cheque";
	}
	echo "</td>";
	echo "</table>";

	//if the delivery address of the current order is not present, retrieve the address from the 'customers' table
	if($ordrow['delivery_add_id'] == 0)
	{
		$addsql = "SELECT * FROM customers WHERE id = " . $ordrow['customer_id'];
		$addres = mysql_query($addsql);
	}
	//if there is no delivery address in the 'customers' tables, retrieve the address from the 'delivery_addresses' table
	else
	{
		$addsql = "SELECT * FROM delivery_addresses WHERE id = " . $ordrow['delivery_add_id'];
		$addres = mysql_query($addsql);
	}
	
	$addrow = mysql_fetch_assoc($addres);

	echo "<table cellpadding=10>";
	echo "<tr>";
	echo "<td><strong>Address</strong></td>";
	echo "<td>" . $addrow['forename'] . " " . $addrow['surname'] . "<br>";
	echo $addrow['add1'] . "<br>";
	echo $addrow['add2'] . "<br>";
	echo $addrow['add3'] . "<br>";
	echo $addrow['postcode'] . "<br>";

	echo "<br>";

	//if the delivery address id is set to 0, display message
	if($ordrow['delivery_add_id'] == 0)
	{
		echo "<i>Address from member account</i>";
	}
	
	//if the delivery address id is set to 1, display message
	else
	{
		echo "<i>Different delivery address</i>";
	}

	echo "</td></tr>";
	echo "<tr><td><strong>Phone</strong></td><td>" . $addrow['phone'] . "</td></tr>";
	echo "<tr><td><strong>Email</strong></td><td><a href='mailto:" . $addrow['email'] . "'>" . $addrow['email'] . "</a></td></tr>";
	echo "</table>";


	$itemssql = "SELECT products.*, orderitems.*, orderitems.id AS itemid FROM products, orderitems WHERE orderitems.product_id = products.id AND order_id = " . $validid;
	$itemsres = mysql_query($itemssql);
	$itemnumrows = mysql_num_rows($itemsres);

	//display information about the products purchased
	echo "<h1>Products Purchased</h1>";

	echo "<table cellpadding=10>";
	echo "<th></th>";
	echo "<th>Product</th>";
	echo "<th>Quantity</th>";
	echo "<th>Price</th>";
	echo "<th>Total</th>";
				
		while($itemsrow = mysql_fetch_assoc($itemsres))
		{	
		
				//display total quantity and price of the product(s) purchased
				$quantitytotal = $itemsrow['price'] * $itemsrow['quantity'];
				$total = $total + $quantitytotal;
				
			//update the orders table
			$totalsql = "UPDATE orders SET total = " . $total . " WHERE id = " . $_SESSION['SESS_ORDERNUM']; 
			$totalres = mysql_query($totalsql);
		echo "<tr>";

				//if the product has no image, display a default image 
				if(empty($itemsrow['image'])) {
					echo "<td><img src='./images/No Image.jpg' width='50' alt='" . $itemsrow['name'] . "'></td>";
				}
				
				//if the product has an image, display that image
				else {
					echo "<td><img src='./images/" . $itemsrow['image'] . "' width='50' alt='" . $itemsrow['name'] . "'></td>";
				}

				echo "<td>" . $itemsrow['name'] . "</td>";
				echo "<td>" . $itemsrow['quantity'] . "</td>";
				echo "<td><strong>&pound;" . sprintf('%.2f', $itemsrow['price']) . "</strong></td>";
				echo "<td><strong>&pound;" . sprintf('%.2f', $quantitytotal) . "</strong></td>";

				echo "</tr>";

		}						

		echo "<tr>";
			echo "<td></td>";
			echo "<td></td>";
			echo "<td></td>";
			
			//display total price of the order
			echo "<td>TOTAL</td>";
			echo "<td><strong>&pound;" . sprintf('%.2f', $total) . "</strong></td>";
	echo "</tr>";

	echo "</table>";

	require("footer.php");
?>
	
