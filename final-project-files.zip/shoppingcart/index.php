<?php
	
//specify files to be integrated in the script
require("header.php");
?>
<script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script>

	<h1>Welcome!!</h1>
	<p>Welcome to the <strong><?php echo $config_sitename; ?></strong> website. Click on the links in this page to explore this website.
	  There is a wide range of products on display in this website. Feel free to move around the site.
     <br>
     <h2>What we sell...</h2>
     <script type="text/javascript">
AC_FL_RunContent( 'codebase','http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0','width','550','height','400','title','products','src','siteimages/zone5','quality','high','pluginspage','http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash','movie','siteimages/zone5' ); //end AC code
</script><noscript><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0" width="550" height="400" title="products">
       <param name="movie" value="siteimages/zone5.swf" />
       <param name="quality" value="high" />
       <embed src="siteimages/zone5.swf" quality="high" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="550" height="400"></embed>
     </object>
 </noscript><br>
     
     
      
	<?php

  require("footer.php");
?>
	
