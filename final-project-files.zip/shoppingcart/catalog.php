<?php
session_start();
require('header.php');
echo "<h1>Product Catalog</h1>";
//sql statement to retrieve all product categories from the database
	$prodsql = "SELECT * FROM products;";
	$prodres = mysql_query($prodsql);
	
	//loop through the category rows then redirect to the products page
	while($prodrow = mysql_fetch_assoc($prodres))
	{
		echo "<li><a href='" . $config_basedir . "addtobasket.php?id=" . $prodrow['id'] . "'>" . $prodrow['name'] . "</a></li>";
	}

?>