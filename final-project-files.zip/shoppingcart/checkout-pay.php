<?php
	session_start();
	
	require("db.php");
	require("functions.php");
	
	//if the user has clicked the 'PayPal' button, begin processing the order	
	if($_POST['paypalsubmit'])
	{
		//update the 'orders' table to show that the order has been completed, update payment type to 1 to indicate the payment mode is Paypal, update status to 2
		$upsql = "UPDATE orders SET status = 2, payment_type = 1 WHERE id = " . $_SESSION['SESS_ORDERNUM'];
		$upres = mysql_query($upsql);

		//sql query to retrieve total price of the order made
		$itemssql = "SELECT total FROM orders WHERE id = " . $_SESSION['SESS_ORDERNUM'];
		$itemsres = mysql_query($itemssql);
		$row = mysql_fetch_assoc($itemsres);

		//if the user is logged in, remove the session order number variable
		if($_SESSION['SESS_LOGGEDIN'])
		{
			unset($_SESSION['SESS_ORDERNUM']);
		}
		
		//if the user is not logged in, create a new session varible called 'SESS_CHANGEID'
		else
		{
			session_register("SESS_CHANGEID");
			$_SESSION['SESS_CHANGEID'] = 1;
		}

		//redirect the page to PayPal with the payment details
		header("Location: https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=ZONE-5%40COMPUTING%40COMPANY&item_name=" . urlencode($config_sitename) . "+Order&item_number=PROD" . $row['id'] ."&amount=" . urlencode(sprintf('%.2f', $row['total'])) . "&no_note=1&currency_code=GBP&lc=GB&submit.x=41&submit.y=15");

	}
	
	//check if the user has clicked on the 'Cheque' payment button
	else if($_POST['chequesubmit'])
	{
		
		//update the 'orders' table to show that the order has been completed, update payment type to 2 to indicate the payment mode is Cheque, update status to 2
		$upsql = "UPDATE orders SET status = 2, payment_type = 2 WHERE id = " . $_SESSION['SESS_ORDERNUM'];
		$upres = mysql_query($upsql);

		//if user is logged in, reset the order session variable
		if($_SESSION['SESS_LOGGEDIN'])
		{
			unset($_SESSION['SESS_ORDERNUM']);
		}
		
		//if user is not logged in, create a new session varible called 'SESS_CHANGEID'
		else
		{
			session_register("SESS_CHANGEID");
			$_SESSION['SESS_CHANGEID'] = 1;
		}

		require("header.php");
?>
		<h1>PAYING BY CHEQUE</h1>
		Please make your cheque payable to <strong><?php echo $config_sitename; ?></strong>.
		<p>
		Send the cheque to:
		<p>
		<?php echo $config_sitename; ?><br>
		345, Zone-5 Computing Company,<br>
		Kenyatta Avenue,<br>
		Nairobi,<br>
		Nairobi County.<br>
<?php
	}
	
	//display shopping cart order summary
	else
	{
		require("header.php");
		echo "<h1>Payment</h1>";
		showcart();
	
?>
		<h2>Select a payment method</h2>
		<form action='checkout-pay.php' method='POST'>
		<table cellspacing=10>
		<tr>
			<td><h3>PayPal</h3></td>
			<td>
			The Zone-5 Computing Company website uses PayPal to accept Switch/Visa/Mastercard cards. No
			PayPal account is required - you simply fill in your credit card details
			and the correct payment will be deducted from your account.
			</td>
			<td><input type="submit" name="paypalsubmit" value="Pay with PayPal"></td>
		</tr>
		<tr>
			<td><h3>Cheque</h3></td>
			<td>
			If you would like to pay by cheque, you can post the cheque for the final
			amount to the Zone-5 Computing Company office.
			</td>
			<td><input type="submit" name="chequesubmit" value="Pay by cheque"></td>
		</tr>
		</table>
		</form>
	
<?php
	}
			
	require("footer.php");
?>
	
	