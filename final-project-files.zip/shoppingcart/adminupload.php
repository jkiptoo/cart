<?php
session_start();

//if the administrator is not logged in, redirect page to the administrato login page
if(isset($_SESSION['SESS_ADMINLOGGEDIN']) == FALSE) {
	header("Location: " . $config_basedir . "adminlogin.php");
}

//specify the maximum size of image to be be uploaded
$MAX_FILE_SIZE = 35000; 

//check if submit button has been clicked
if($_POST['submit']) {
	
	//if user has clicked submit button without uploading a file, display error message 
	if($_FILES['userfile']['name'] == '') {
		header("Location: " . $config_basedir . "adminupload.php?error=nophoto");
		exit;
	}
	
	//if the size of the image is zero, display error message
	elseif($_FILES['userfile']['size'] == 0) {
		header("Location: " . $config_basedir . "adminupload.php?error=photoprob");
		exit;
	}
	
	//if the user tries to upload an image file that is not of jpeg format, display error message
	elseif($_FILES["userfile"]["type"] != "image/jpeg") {
		header("Location: " . $config_basedir . "adminupload.php?error=imagetype");
		exit;
		}

	//check if the size of the image uploaded is greater than the specified maximum image file size
	elseif($_FILES['userfile']['size'] > $MAX_FILE_SIZE) {
		header("Location: " . $config_basedir . "adminupload.php?error=large");
		exit;
		
	}
	
	//if the image uploaded has another unspecified problem, display error message
	elseif(!getimagesize($_FILES['userfile']['tmp_name'])) {
		header("Location: " . $config_basedir . "adminupload.php?error=invalid");
		exit;
	}
	else {
		
		//specify upload directory to which the image files are to be uploaded in 
		$uploaddir = "C:/xampplite/htdocs/shoppingcart/images/";
	   $uploadfile = $uploaddir . $_FILES['userfile']['name'];
	   
	   //check if the image being uploaded already exists; if it exists, display error message
	   if (file_exists($uploaddir . $_FILES["file"]["name"]))
      {
      header("Location: " . $config_basedir . "adminupload.php?error=exists");
	  exit;
	  }
	   
	   //move uploaded image from the temporary folder and store it permanently in the images folder
	   if(move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
			
			header("Location: " . $config_basedir . "adminhome.php");
			exit;
	   }
	   
	   //if any unspecified error occurs during uploading, display a general error message
	   else {
	       echo 'There was a problem uploading your file.<br />';
	   }
	} 	
}
else {
	require("header.php");
echo "<h1>Upload product images</h1>";
echo "<p>";
echo "<a href='adminhome.php'><--- Return to the administrative panel</a>";
echo "<p>";
}

//range of error messages that can be displayed
switch($_GET['error']) {

		case "empty":
			echo 'You did not select anything.';
		break;

		case "nophoto":
			echo 'You did not select a image to upload.';
		break;

		case "photoprob":
			echo 'There appears to be a problem with the image your are uploading';
		break;

		case "large":
			echo 'The image you selected is too large';
		break;
		
		case "invalid":
			echo 'The image you selected is not a valid image file';
		break;
		
		case "exists":
			echo 'The image you are trying to upload already exists. Please try to upload another image file.';
		break;
		
		case "imagetype":
			echo 'Please select an image which is in a jpeg format';
		break;
	}
?>


<form enctype="multipart/form-data" action="adminupload.php" method="POST">

<table>
<tr>
   <td>Image to upload</td>
   <td><input name="userfile" type="file"></td>
</tr>
<tr>
	<td><input type="submit" name="submit" value="Upload File"></td>
</tr>
</table>
</form>

<?php
require("footer.php");
?>

