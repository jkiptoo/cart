<?php

//specify host details
$dbhost = "localhost";

//specify database username
$dbuser = "root";

//specify database connection password
$dbpassword = "";

//specify the name of the database
$dbdatabase = "dbcart";

//specify the directory in which website is located
$config_basedir = "http://localhost/shoppingcart/";

//specify the name of the website
$config_sitename = "ZONE-5 COMPUTING ONLINE SHOP";

?>
