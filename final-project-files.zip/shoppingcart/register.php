<?php

session_start();

require("config.php");

//database connection details
$db = mysql_connect($dbhost, $dbuser, $dbpassword);
mysql_select_db($dbdatabase, $db);

//check if the required fields  are empty
if($_POST['submit']){
	if(empty($_POST['username']) ||
		empty($_POST['password1']) ||
		empty($_POST['password2']) ||
		empty($_POST['email'])) {
			
			//if required fields are empty, display error message
			header("Location: " .$config_basedir. "register.php?error=empty");
			exit;	
	}
	
	//check if the email address entered is valid 
	$stremail = $_POST['email'];
	$result = ereg("^[^@]+@[^@]+\.[^@]+$",$stremail,$trashed);
	if(!$result){
		header("Location: " .$config_basedir. "register.php?error=email");
		exit;	
	}
	
	//check if the second password entered matches the first password
	else {
	if($_POST['password1'] == $_POST['password2']) {
		$checksql = "SELECT * FROM users WHERE username = '" . $_POST['username'] . "';";
		$checkresult = mysql_query($checksql);
		$checknumrows = mysql_num_rows($checkresult);
		
		if($checknumrows == 1) {
			header("Location: " . $config_basedir . "register.php?error=taken");
			exit;
			}
			else 
			{
				for($i = 0; $i < 16; $i++) {
				$randomstring.= chr(mt_rand(32,126));
			}

			$verifyurl = "verify.php";
			$verifystring = urlencode($randomstring);
			$verifyemail = urlencode($_POST['email']);
			$validusername = $_POST['username'];

			$sql = "INSERT INTO users(username, password, email, verifystring, active) VALUES('"
				. $_POST['username']
				. "', '" . $_POST['password1']
				. "', '" . $_POST['email']
				. "', '" . addslashes($randomstring)
				. "', 0);";
			echo $sql;
			mysql_query($sql);
												
$mail_body=<<<_MAIL_

Hi $validusername,

Your account has been created in Zone-5 Computing Company website. Please click on the following link to verify your new account:

$verifyurl?email=$verifyemail&verify=$verifystring

_MAIL_;
			
			mail($_POST['email'], $config_sitename . " User verification", $mail_body);

			require("header.php");
			echo "A link has been emailed to the address you provided. Please follow the link in the email to validate your account."; 			
		}
	}
	else {
		header("Location: " . $config_basedir . "register.php?error=pass");
	}
}
}

else {
	require("header.php");
	echo "<h1>Register</h1>";
	
	switch($_GET['error']) {
		case "email":
		echo "<strong>That is an invalid email address. Please enter a valid email address.</strong>"; 
		break;
		
		case "empty":
		    echo "<strong>Please fill in the required fields.</strong>";
			break;
			
		case "pass":
			echo "<strong>Passwords do not match!</strong>";
		break;

		case "taken":
			echo "<strong>This Username has been already taken, please use another.</strong>";
		break;

		case "no":
			echo "<strong>Incorrect registration details!</strong>";
		break;

	}
?>
	<p>
	To register on the <?php echo $config_sitename; ?> website, please fill in the form below.
	<form action="<?php echo $SCRIPT_NAME ?>" method="POST">
	<table>
	<tr>
		<td>Username</td>
		<td><input type="text" name="username"></td>
	</tr>
	<tr>
		<td>Password</td>
		<td><input type="password" name="password1"></td>
	</tr>
	<tr>
		<td>Password (again)</td>
		<td><input type="password" name="password2"></td>
	</tr>
	<tr>
		<td>Email</td>
		<td><input type="text" name="email"></td>
	</tr>
	<tr>
		<td></td>
		<td><input type="submit" name="submit" value="JOIN US"></td>
	</tr>
	</table>
	</form>

<?php
}
require("footer.php");

?>