<h1>Browse Product Categories</h1>
<ul>
<?php

//sql statement to retrieve all product categories from the database
	$catsql = "SELECT * FROM categories;";
	$catres = mysql_query($catsql);
	
	//loop through the category rows then redirect to the products page
	while($catrow = mysql_fetch_assoc($catres))
	{
		echo "<li><a href='" . $config_basedir . "products.php?id=" . $catrow['id'] . "'>" . $catrow['name'] . "</a></li>";
	}

?>
</ul>

