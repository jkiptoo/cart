-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 18, 2010 at 07:12 PM
-- Server version: 5.1.37
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dbcart`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL DEFAULT '',
  `password` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '123');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Laptops'),
(2, 'Desktops'),
(3, 'PDAs'),
(4, 'Servers'),
(5, 'Projectors'),
(6, 'Keyboards');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `forename` varchar(50) NOT NULL DEFAULT '',
  `surname` varchar(50) NOT NULL DEFAULT '',
  `add1` varchar(50) NOT NULL DEFAULT '',
  `add2` varchar(50) NOT NULL DEFAULT '',
  `add3` varchar(50) NOT NULL DEFAULT '',
  `postcode` varchar(10) NOT NULL DEFAULT '',
  `phone` varchar(20) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `registered` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `forename`, `surname`, `add1`, `add2`, `add3`, `postcode`, `phone`, `email`, `registered`) VALUES
(1, 'Craig', 'Tucker', '19, The Grove', 'Red Crescent Lane', 'Avenue Street', 'T3 TR4', '037549394858', 'craigt@yahoo.com', 1),
(2, 'Lee', 'Jordan', 'North Avenue Road', 'London West  Ave', 'London West  Ave', 'T1 FG3', '047467363374', 'jordanjones@hotmail.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `delivery_addresses`
--

CREATE TABLE IF NOT EXISTS `delivery_addresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `forename` varchar(50) NOT NULL DEFAULT '',
  `surname` varchar(50) NOT NULL DEFAULT '',
  `add1` varchar(50) NOT NULL DEFAULT '',
  `add2` varchar(50) NOT NULL DEFAULT '',
  `add3` varchar(50) NOT NULL DEFAULT '',
  `postcode` varchar(10) NOT NULL DEFAULT '',
  `phone` varchar(20) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `delivery_addresses`
--

INSERT INTO `delivery_addresses` (`id`, `forename`, `surname`, `add1`, `add2`, `add3`, `postcode`, `phone`, `email`) VALUES
(1, 'eric', 'tom', '1234', 'nairobi', 'nairobi', '0100', '78654433', 'eric@yahoo.com'),
(2, 'Craig', 'Tucker', '1234', 'Nairobi', 'Nairobi', '0100', '12444', 'craig@yahoo.com'),
(3, 'Allan', 'Reid', '25345', 'Nairobi', 'Nairobi', '0100', '16172828', 'allang@yahoo.com');

-- --------------------------------------------------------

--
-- Table structure for table `orderitems`
--

CREATE TABLE IF NOT EXISTS `orderitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL DEFAULT '0',
  `product_id` int(11) NOT NULL DEFAULT '0',
  `quantity` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `orderitems`
--

INSERT INTO `orderitems` (`id`, `order_id`, `product_id`, `quantity`) VALUES
(1, 1, 1, 4),
(2, 1, 3, 3),
(3, 2, 1, 1),
(4, 3, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL DEFAULT '0',
  `registered` int(11) NOT NULL DEFAULT '0',
  `delivery_add_id` int(11) NOT NULL DEFAULT '0',
  `payment_type` int(11) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `session` varchar(50) NOT NULL DEFAULT '',
  `total` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customer_id`, `registered`, `delivery_add_id`, `payment_type`, `date`, `status`, `session`, `total`) VALUES
(1, 0, 0, 1, 0, '2010-11-05 09:55:07', 1, 'mlnt5e8mqv281cvt0qp3su6997', 0),
(2, 0, 0, 0, 0, '2010-11-06 17:36:44', 0, '6j2ih2iaeftmfd1dvhfvs78g86', 0),
(3, 1, 1, 2, 1, '2010-11-07 18:02:04', 2, '', 0),
(4, 0, 0, 3, 0, '2010-11-17 21:04:18', 1, '1fkvlqoivmchv5mdr6hl7h1r97', 0);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `cat_id` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `image` varchar(30) NOT NULL DEFAULT '',
  `price` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `cat_id`, `name`, `description`, `image`, `price`) VALUES
(1, 1, 'Compaq Presario CQ60-200ED', 'The best laptop in the market that fits every aspect of computing.', 'compaq2.jpg', 500),
(2, 1, 'Toshiba Quismio', 'A compact laptop which can be easily carried around.', '', 300.19),
(3, 1, 'IBM Ipad', 'Lightweight laptop', 'ipad.jpg', 100),
(4, 3, 'HP Jornada 568', 'A durable Personal digital assistant', 'hpj.jpg', 250),
(5, 4, 'HP Proliant', 'A server sutable for your enterprise needs', 'proliant.jpg', 1000),
(6, 4, 'Dell XP345', 'A server suitable for small businesses', '', 923.05),
(7, 1, 'Compaq Presario CQ61-106D', 'Nice business notebook', 'compaq2.jpg', 545.67),
(8, 5, 'Sony', 'Best', '', 234);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `customer_id` int(4) NOT NULL DEFAULT '0',
  `username` varchar(10) NOT NULL DEFAULT '',
  `password` varchar(10) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL,
  `verifystring` int(20) NOT NULL,
  `active` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `customer_id`, `username`, `password`, `email`, `verifystring`, `active`) VALUES
(1, 1, 'craig', '1234', 'craigt@yahoo.com', 0, 1),
(2, 2, 'lee', '12345', 'jordanjones@hotmail.com', 0, 1),
(3, 0, 'Joel', '22', 'joelchepkwony@gmail.com', 0, 0),
(4, 0, 'allan', '1234', 'allan@yahoo.com', 0, 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
